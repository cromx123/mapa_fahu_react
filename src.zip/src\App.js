// src/App.js
import React from "react";
import CampusMapScreen from "./components/CampusMapScreen";

export default function App() {
  return <CampusMapScreen />;  // ← el mapa es la pantalla inicial
}
